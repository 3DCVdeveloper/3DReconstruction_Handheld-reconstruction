//
//  context.hpp
//  Uplink
//
//  Copyright (c) 2015 Occipital, Inc. All rights reserved.
//

# pragma once

# include "./context.h"

namespace uplink {

//------------------------------------------------------------------------------

//------------------------------------------------------------------------------

}
