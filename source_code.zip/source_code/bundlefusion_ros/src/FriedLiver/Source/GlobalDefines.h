
#pragma once
#ifndef _GLOBAL_DEFINES_
#define _GLOBAL_DEFINES_

#define MINF __int_as_float(0xff800000)

#define MAX_MATCHES_PER_IMAGE_PAIR_RAW 128
#define MAX_MATCHES_PER_IMAGE_PAIR_FILTERED 25


#define USE_LIE_SPACE

#endif //_GLOBAL_DEFINES_