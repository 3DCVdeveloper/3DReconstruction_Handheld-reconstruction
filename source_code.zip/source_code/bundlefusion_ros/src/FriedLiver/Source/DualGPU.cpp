
//#include "stdafx.h"

#include "DualGPU.h"

