
//TODO fix hack

//#define USE_LIE_SPACE
//#define USE_CPU_SOLVE
#define USE_GPU_SOLVE