

//#include "stdafx.h"


#include "mLibCore.cpp"
#include "mLibDepthCamera.cpp"
//#include "mLibZLib.cpp"
//#include "mLibLodePNG.cpp"
//#include "mlibD3D11.cpp"
