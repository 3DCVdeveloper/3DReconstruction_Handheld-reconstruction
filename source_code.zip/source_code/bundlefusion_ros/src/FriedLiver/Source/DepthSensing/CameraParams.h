#pragma once

#ifndef _CAMERA_PARAMS_
#define _CAMERA_PARAMS_

struct CameraParams
{
	float fx;
	float fy;
	float ux;
	float uy;
};

#endif