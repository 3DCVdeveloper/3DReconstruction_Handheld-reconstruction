#include "stdafx.h"
#include "CUDASceneRepHashSDF.h"


Timer CUDASceneRepHashSDF::m_timer;