#ifndef RGBDSLAM_RENDERABLE_H
#define RGBDSLAM_RENDERABLE_H

class Renderable {
  public:
  virtual void render() = 0;
};

#endif
