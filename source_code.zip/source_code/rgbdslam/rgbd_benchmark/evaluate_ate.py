#!/usr/bin/env python
import pyximport; pyximport.install()
import evaluate_ate_module as mypyxmodule

mypyxmodule.main()
