#Replaced by associate_module.pyx, which is imported in evaluate_ate_module
